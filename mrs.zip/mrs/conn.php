<?php
define('HOST', 'localhost');
define('USER', '');
define('PASS', '');
define('DB', 'mrs');

$connect=mysqli_connect(HOST,USER,PASS,DB) or die("cannot connect to the database.");

?>