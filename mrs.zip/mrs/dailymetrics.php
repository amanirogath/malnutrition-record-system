<?php
$message="";

include('conn.php');

session_start();
if(empty($_SESSION['identity'])){
    header("location:index.php");
    die();
}

if(isset($_POST['fnd'])){
	header("location:result.php");
}

$id=$_GET['key'];


// INSERT INTO `records`(`id`, `child_id`, `date`, `height`, `weight`, `muac`, `temperature`,
//  `observation`, `status`, `staff_id`, `comment`, `location_id`) 

if(isset($_POST['add'])){
    $ht=$_POST['height'];
    $wt=$_POST['weight'];
    $muac=$_POST['muac'];
    $temp=$_POST['tempereture'];
    $ob=$_POST['ob'];
    $cmt=$_POST['comment'];
    $stat="CENTER";
    $supl=$_POST['supl'];
    $how=$_POST['dose'];
    $aidii=$_SESSION['identity'];

    $dt=date('Y-m-d');

   //change child 'new' status

   $supd="UPDATE `rehabilitation` SET `status`='ODINARY' WHERE `child_id`='$id'";
   $sin=mysqli_query($connect,$supd);


   $inj="INSERT INTO `records`(`child_id`, `date`, `height`, `weight`, 
    `muac`, `temperature`,`status`,`staff_id`,`observation`,`comment`,`suppliment`,`dose`)
     value('$id','$dt','$ht','$wt','$muac','$temp','$stat','$aidii','$ob','$cmt','$supl','$how')";

    $ins=mysqli_query($connect,$inj);
if($ins){
 
    header("location:viewcenter.php");
//     $message=" <div class='alert alert-success alert-dismissible fade show'>
//     <button type='button' class='close h-100' data-dismiss='alert' aria-label='Close'><span><i class='mdi mdi-close'></i></span>
//     </button>
//     <strong>Success!</strong> $nm Informations have been recorded.
// </div>";
}
else{
    $message=" <div class='alert alert-danger alert-dismissible fade show'>
    <button type='button' class='close h-100' data-dismiss='alert' aria-label='Close'><span><i class='mdi mdi-close'></i></span>
    </button>
    <strong>Error!</strong> Informations have NOT been recorded.
</div>";
}

	// header("location:result.php");
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Dashboard</title>
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="images/favicon.png">
    <link href="vendor/jqvmap/css/jqvmap.min.css" rel="stylesheet">
	<link rel="stylesheet" href="vendor/chartist/css/chartist.min.css">
    <link href="vendor/bootstrap-select/dist/css/bootstrap-select.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
	<link href="../../cdn.lineicons.com/2.0/LineIcons.css" rel="stylesheet">

</head>
<body>

 
<?php include("topbar.php");?>
        
       
        <!--**********************************
            Sidebar start
        ***********************************-->
        <?php

        $g=$_SESSION['stat'];
        
        if($g=="ADMIN"){
            include("sidebar.php");
								}
								else{
                                    include("userside.php");
								}

                                ?>
        <!--**********************************
            Sidebar end
        ***********************************-->
		
		<!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">
            <!-- row -->
			<div class="container-fluid">
				<div class="form-head d-flex mb-3 align-items-start">
					<div class="mr-auto d-none d-lg-block">
						<h2 class="text-black font-w600 mb-0">Rehabilitation Center Metrics</h2>
						<p class="mb-0"><?php echo $_SESSION['name'];?> , Please fillout the metrics of the child</p>
					</div>
					
					
				</div>
            
                <div class="col-xl-12 col-lg-12">
                        <div class="card">
                        <div class="card-header">
                        
                                <p><?php $sel="SELECT * FROM `children` WHERE `special_id`='$id'";
                                         $ver=mysqli_query($connect,$sel);
                                         $fe=mysqli_fetch_array($ver);
                                         echo $fe['full_name'] .', Gender: '.$fe['gender'] .', DOB: '.$fe['dob'] .', Status :'.$fe['status'];
                                         
                                         ?> </p>
                            </div>
                            <?php echo $message; ?>

                            <div class="card-body">
                                <div class="basic-form">
                                    <form method="POST">

                                        <div class="form-row">
                                        <div class="form-group col-md-6">
                                                <label>Weight</label>
                                                <input type="number" name="weight" class="form-control"name="name" min="1" max="120" placeholder="child's weight (kg)" required="required">
                                            </div>
                                            <div class="form-group col-md-6">
                                                <label>Height</label>
                                                <input type="number" name="height" class="form-control"name="dob" min="1" max="200" placeholder="child's height (cm)" required="required">
                                            </div>
                                            <div class="form-group col-md-6">
                                                <label>MUAC (mid-uper arm circumfrence)</label>
                                                <input type="number" class="form-control"name="muac" min="6" max="32" placeholder="child's muac units (cm)" required="required">
                                            </div>
                                            <div class="form-group col-md-6">
                                                <label>Tempereture</label>
                                                <input type="number" class="form-control"name="tempereture" min="30" max="60" placeholder="child's body tempereture (c&deg;)" required="required">
                                            </div>
                                            <div class="form-group col-md-6">
                                                <label>observation</label>
                                                <input type="text" name="ob" class="form-control" placeholder="observation" required="required">
                                            </div>
                                            <div class="form-group col-md-6">
                                                <label>comment</label>
                                                <textarea class="form-control" name="comment" rows="4" id="comment" placeholder="comment from the health professional" required="required"></textarea>
                                            </div>
                                            <div class="form-group col-md-6">
                                                <label>Supliment(s)</label>
                                                <select class="form-control form-control-lg" name="supl">

                                                <?php
                                                $cel="SELECT * FROM `pharmacetics`";
                                                $cer=mysqli_query($connect,$cel);
                                                $c=1;
                                                while( $ce=mysqli_fetch_array($cer)){
                                                 echo   '<option value="'.$ce["id"].'">'.$ce["name"].'</option>';
                                                
                                                $c++;
                                                }
                                                ;

                                                ?>
                                              
                                              

                                            </select>
                                            </div>
                                            <div class="form-group col-md-6">
                                                <label>Dose Assigned</label>
                                                <input type="text" name="dose" class="form-control" placeholder="Dose Assigned of Medication">
                                            </div>

                                        <div class="form-group col-md-6">
                                        <label></label>
                                        <button type="submit" name="add" class="btn btn-success">Save record</button>
                                   
                                              </div>
                                        </div>
                                       
                                    </form>
                                </div>
                            </div>
                        </div>
					</div>
 			
			
				
				 </div>
            
        </div>
        <!--**********************************
            Content body end
        ***********************************-->

        <!--**********************************
            Footer start
        ***********************************-->
        <div class="footer">
            <div class="copyright">
                <p>Copyright © Developed by <a href="">Amani R Leoni </a> 2021-<?php echo date("Y");?></p>
            </div>
        </div>
        <!--**********************************
            Footer end
        ***********************************-->

		<!--**********************************
           Support ticket button start
        ***********************************-->

        <!--**********************************
           Support ticket button end
        ***********************************-->


    </div>
    <!--**********************************
        Main wrapper end
    ***********************************-->

    <!--**********************************
        Scripts
    ***********************************-->
    <!-- Required vendors -->
    <script src="vendor/global/global.min.js"></script>
	<script src="vendor/bootstrap-select/dist/js/bootstrap-select.min.js"></script>
	<script src="vendor/chart.js/Chart.bundle.min.js"></script>
    <script src="js/custom.min.js"></script>
	<script src="js/deznav-init.js"></script>
	
	<!-- Counter Up -->
    <script src="vendor/waypoints/jquery.waypoints.min.js"></script>
    <script src="vendor/jquery.counterup/jquery.counterup.min.js"></script>	
		
	<!-- Apex Chart -->
	<script src="vendor/apexchart/apexchart.js"></script>	
	
	<!-- Chart piety plugin files -->
	<script src="vendor/peity/jquery.peity.min.js"></script>
	
	<!-- Dashboard 1 -->
	<script src="js/dashboard/dashboard-1.js"></script>
	
	
</body>

</html>