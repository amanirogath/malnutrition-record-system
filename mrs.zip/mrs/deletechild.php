<?php 

session_start();
include('conn.php');
if(empty($_SESSION['identity'])){
    header("location:index.php");
    die();
}

$aidi=$_GET['key'];

$g=$_SESSION['stat'];

if($g=="ADMIN"){
                 }
                 else{
                   die();
                 }

$del1="DELETE FROM `children` WHERE special_id='$aidi'";
$dele1=mysqli_query($connect,$del1);


$del2="DELETE FROM `records` WHERE child_id='$aidi'";
$dele2=mysqli_query($connect,$del2);




$del3="DELETE FROM `rehabilitation` WHERE child_id='$aidi'";
$dele3=mysqli_query($connect,$del3);



header("location:children.php");

?>