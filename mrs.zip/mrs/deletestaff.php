<?php
session_start();
include('conn.php');
$ki=$_GET['key'];


$g=$_SESSION['stat'];

if($g=="ADMIN"){
                       
                        
$sw="DELETE FROM `users` WHERE `special_id`='$ki'";

    $cco=mysqli_query($connect,$sw);
    if ($cco) {
        header("location:viewstaff.php");
        
    }
    else
    {
    echo "cannot delete admin";
    }
}
    else{
        die();
      }
    ?>