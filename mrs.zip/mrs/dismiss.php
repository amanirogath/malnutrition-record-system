<?php
session_start();
include('conn.php');
if(empty($_SESSION['identity'])){
    header("location:index.php");
    die();
}

$id=$_GET['key'];
$date=date('d-m-Y');
$status="RECOVERED";

//child name
$kdz="SELECT * FROM `rehabilitation` WHERE `child_id`='$id'";
$kdfz=mysqli_query($connect,$kdz);
$kddz=mysqli_fetch_array($kdfz);
$cid=$kddz['center_id'];



//child name
$kd="SELECT * FROM `children` WHERE `special_id`='$id'";
$kdf=mysqli_query($connect,$kd);
$kdd=mysqli_fetch_array($kdf);
$name=$kdd['full_name'];



//center name
$kdl="SELECT * FROM `locations` WHERE `special_id`='$cid'";
$kdlz=mysqli_query($connect,$kdl);
$kdlf=mysqli_fetch_array($kdlz);
$center=$kdlf['center_name'];



$ex="UPDATE `rehabilitation` SET `status`='$status',`date_end`='$date' WHERE `child_id`='$id'";
$exe=mysqli_query($connect,$ex);
if($exe){
    $api_key='f6fdef81b56d47e8';
$secret_key = 'ZGI3ZTRmZTk3NDE3MzMwZWMyNmQ2MDliMGRkY2Q5YTFhMDc3MzBjNjUxZDA2OWVmN2Q5YTJmZjYzMWYxZTJhNQ==';

$postData = array(
    'source_addr' => 'INFO',
    'encoding'=>0,
    'schedule_time' => '',
    'message' => '(M.R.S), Your child ('.$name.') have been dismissed from the center('.$center.'),for help / support contact 0743722720 or 0716122124',
    'recipients' => [array('recipient_id' => '1','dest_addr'=>'255743722720')]
);

// 'recipients' => [array('recipient_id' => '1','dest_addr'=>'255746734813'),array('recipient_id' => '2','dest_addr'=>'255743722720')]


$Url ='https://apisms.beem.africa/v1/send';

$ch = curl_init($Url);
error_reporting(E_ALL);
ini_set('display_errors', 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt_array($ch, array(
    CURLOPT_POST => TRUE,
    CURLOPT_RETURNTRANSFER => TRUE,
    CURLOPT_HTTPHEADER => array(
        'Authorization:Basic ' . base64_encode("$api_key:$secret_key"),
        'Content-Type: application/json'
    ),
    CURLOPT_POSTFIELDS => json_encode($postData)
));

$response = curl_exec($ch);

if($response === FALSE){
        echo $response;

    die(curl_error($ch));
}
var_dump($response);
    header("location:viewcenter.php");
}
else{
    echo "Cannot send information";
}

?>