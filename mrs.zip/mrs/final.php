<?php
$message="";
include('conn.php');
session_start();
if(empty($_SESSION['identity'])){
    header("location:index.php");
    die();
}

if(isset($_POST['fnd'])){
	header("location:result.php");
}
$identity=$_SESSION['identity'];
$id=$_SESSION['kid'];

//fetch the data
$disp="SELECT `height`, `weight`, `muac`, `temperature` FROM `records` WHERE `child_id`='$id'  ORDER BY `records`.`id` DESC LIMIT 1";
$dispm=mysqli_query($connect,$disp);
$dispf=mysqli_fetch_array($dispm);
$height=$dispf['height'];
$weight=$dispf['weight'];
$muac=$dispf['muac'];
$temp=$dispf['temperature'];

//caliculation
  // to caliculate bmi 
  $hm=$height/100;
  $bm=$hm*$hm;
  $bmi=$weight/$bm; 
                 switch($bmi){
                              case ($bmi>=30):
                                $bmires="OBESE";
                                break;
                              case ($bmi<=13):
                                $bmires="UNDERWEIGHT";
                                break; 
                              default:
                              $bmires="NORMAL";
                             }

                             switch($temp){
                                case ($temp>=37.5):
                                  $tempres="HIGH";
                                  break;
                                case ($temp<=35.9):
                                  $tempres="LOW";
                                  break; 
                                default:
                                $tempres="NORMAL";
                               }

                               switch($muac){
                                    case ($muac>=6 && $muac<=11.4):
                                    $muacres="VERY UNDER";
                                    break;
                                    case ($muac>=11.5 && $muac<=12.4):
                                    $muacres="VERY UNDER";
                                    break; 
                                    case ($muac>=12.5 && $muac<=13.5):
                                    $muacres="UNDER";
                                    break;
                                default:
                                $muacres="NORMAL";
                               }

//end caliculation
//end fetch the data

if(isset($_POST['add'])){
    $ob=$_POST['ob'];
    $cm=$_POST['comment'];
    $supl=$_POST['supl'];
    $how=$_POST['dose'];
    $sam=$_POST['sam'];
    $mic=$_POST['mic'];

   $inc="UPDATE `records` SET `observation`='$ob',`comment`='$cm',`staff_id`='$identity',`suppliment`='$supl',`dose`='$how',`sam`='$sam',`mic`='$mic' WHERE `child_id`='$id'  ORDER BY `records`.`id` DESC LIMIT 1";

    $insc=mysqli_query($connect,$inc);

if($insc){
 
    $message=" <div class='alert alert-success alert-dismissible fade show'>
    <button type='button' class='close h-100' data-dismiss='alert' aria-label='Close'><span><i class='mdi mdi-close'></i></span>
    </button>
    <strong>Success!</strong> Informations have been recorded.
</div>";
header("location:children.php");
}
else{
    $message=" <div class='alert alert-danger alert-dismissible fade show'>
    <button type='button' class='close h-100' data-dismiss='alert' aria-label='Close'><span><i class='mdi mdi-close'></i></span>
    </button>
    <strong>Error!</strong> Informations have NOT been recorded.
</div>";

}

	// header("location:result.php");
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Dashboard</title>
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="images/favicon.png">
    <link href="vendor/jqvmap/css/jqvmap.min.css" rel="stylesheet">
	<link rel="stylesheet" href="vendor/chartist/css/chartist.min.css">
    <link href="vendor/bootstrap-select/dist/css/bootstrap-select.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
	<link href="../../cdn.lineicons.com/2.0/LineIcons.css" rel="stylesheet">

</head>
<body>

<?php include("topbar.php");?>
        
       
        <!--**********************************
            Sidebar start
        ***********************************-->
        <?php

        $g=$_SESSION['stat'];
        
        if($g=="ADMIN"){
            include("sidebar.php");
								}
								else{
                                    include("userside.php");
								}

                                ?>
     
        <!--**********************************
            Sidebar end
        ***********************************-->
		
		<!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">
            <!-- row -->
			<div class="container-fluid">
				<div class="form-head d-flex mb-3 align-items-start">
					<div class="mr-auto d-none d-lg-block">
						<h2 class="text-black font-w600 mb-0">Conclusion</h2>
						<p class="mb-0"><?php echo $_SESSION['name'];?> , Please record your analyis of the child</p>
					</div>
					
					
				</div>
            
                <div class="col-xl-12 col-lg-12">
                        <div class="card">
                        <div class="card-header">
                            
                        <!-- $ress="SELECT * FROM `records` WHERE `special_id`='$k' ORDER BY `records`.`id` DESC" -->
                                <p><?php $sel="SELECT * FROM `children` WHERE `special_id`='$id'";
                                         $ver=mysqli_query($connect,$sel);
                                         $fe=mysqli_fetch_array($ver);
                                         echo $fe['full_name'] .', Gender: '.$fe['gender'] .', DOB: '.$fe['dob'] .', Status :'.$fe['status'];
                                         
                                         ?> </p>
                            </div>
                            <?php echo $message; ?>

                            <div class="card-body">

                            <table class="col-xl-12 col-lg-12">
                            <th>HEIGHT</th>
                            <th>WEIGHT</th>
                            <th>MUAC (mid-uper arm circumfrence)</th>
                            <th>TEMPERETURE</th>
                            <tr>
                            <td><?php echo $height;?></td>
                            <td><?php echo $weight;?></td>
                            <td><?php echo $muac;?></td>
                            <td><?php echo $temp;?>(c&deg;)</td>
                            </tr>
                            </table>

                            <br>
                            <p>Summary on Metrics</p>

                            <table class="col-xl-12 col-lg-12">
                            <th>BMI (body mas index)</th>
                            <th>MUAC (mid-uper arm circumfrence)</th>
                            <th>Tempereture</th>
                            
                            <tr>

                            <td><span class="badge light badge-success"><?php echo $bmires.'--'.round($bmi,1);?></span></td>
                            <td><span class="badge light badge-warning"><?php echo $muacres;?></span></td>
                            <td><span class="badge light badge-info"><?php echo $tempres;?></span></td>
                            </tr>
                            </table>

                                         <br>
                                <div class="basic-form">
                                    <form method="POST">

                                        <div class="form-row">
                                            <div class="form-group col-md-6">
                                                <label>observation</label>
                                                <input type="text" name="ob" class="form-control" placeholder="observation" required="required">
                                            </div>
                                            <div class="form-group col-md-6">
                                                <label>comment</label>
                                                <textarea class="form-control" name="comment" rows="4" id="comment" placeholder="comment from the health professional" required="required"></textarea>
                                            </div>
                                            <div class="form-group col-md-6">
                                                <label>Final severe acute malnutrition diagonisis</label>
                                                <select class="form-control form-control-lg" name="sam">
                                                <option value="none">none</option>
                                                <option value="kwashiokor">kwashiokor</option>
                                                <option value="marasmus">marasmus</option>
                                                <option value="marasmic kwashiokor">marasmic-kwashiokor</option>
                                            </select>
                                            </div>
                                            <div class="form-group col-md-6">
                                                <label>Final Micronutrient diagonisis</label>
                                                <select class="form-control form-control-lg" name="mic">
                                                <option value="none">none</option>
                                                <option value="iodine defficiency">iodine defficiency</option>
                                                <option value="iron defficiency">iron defficiency</option>
                                                <option value="vitamin a defficiency">vitamin a defficiency</option>
                                                <option value="vitamin c defficiency">vitamin c defficiency</option>
                                            </select>
                                            </div>
                                            <div class="form-group col-md-6">
                                                <label>Supliment(s)</label>
                                                <select class="form-control form-control-lg" name="supl">

                                                <?php
                                                $cel="SELECT * FROM `pharmacetics`";
                                                $cer=mysqli_query($connect,$cel);
                                                $c=1;
                                                while( $ce=mysqli_fetch_array($cer)){
                                                 echo   '<option value="'.$ce["id"].'">'.$ce["name"].'</option>';
                                                
                                                $c++;
                                                }
                                                ;

                                                ?>
                                              
                                              

                                            </select>
                                            </div>
                                            <div class="form-group col-md-6">
                                                <label>Dose Assigned</label>
                                                <input type="text" name="dose" class="form-control" placeholder="Dose Assigned of Medication">
                                            </div>
                                            
                                        <div class="form-group col-md-6">
                                        <label></label>
                                        <button type="submit" onclick="return ask();" name="add" class="btn btn-success">Complete</button>
                                   
                                              </div>
                                        </div>
                                       
                                    </form>
                                </div>
                            </div>
                        </div>
					</div>
 			
			
				
				 </div>
            
        </div>
        <!--**********************************
            Content body end
        ***********************************-->

        <!--**********************************
            Footer start
        ***********************************-->
        <div class="footer">
            <div class="copyright">
                <p>Copyright © Developed by <a href="">Amani R Leoni </a> 2021-<?php echo date("Y");?></p>
            </div>
        </div>
        <!--**********************************
            Footer end
        ***********************************-->

		<!--**********************************
           Support ticket button start
        ***********************************-->

        <!--**********************************
           Support ticket button end
        ***********************************-->


    </div>
    <!--**********************************
        Main wrapper end
    ***********************************-->

    <!--**********************************
        Scripts
    ***********************************-->
    <script>
     function ask() {
       var a=confirm("Submit the information(OK to confirm)? ");
       if(a==true){
        return true;
       }else{
        return false;
       }
     }
   </script>
    <!-- Required vendors -->
    <script src="vendor/global/global.min.js"></script>
	<script src="vendor/bootstrap-select/dist/js/bootstrap-select.min.js"></script>
	<script src="vendor/chart.js/Chart.bundle.min.js"></script>
    <script src="js/custom.min.js"></script>
	<script src="js/deznav-init.js"></script>
	
	<!-- Counter Up -->
    <script src="vendor/waypoints/jquery.waypoints.min.js"></script>
    <script src="vendor/jquery.counterup/jquery.counterup.min.js"></script>	
		
	<!-- Apex Chart -->
	<script src="vendor/apexchart/apexchart.js"></script>	
	
	<!-- Chart piety plugin files -->
	<script src="vendor/peity/jquery.peity.min.js"></script>
	
	<!-- Dashboard 1 -->
	<script src="js/dashboard/dashboard-1.js"></script>
	
	
</body>

</html>