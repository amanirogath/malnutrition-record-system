<div class="footer">
            <div class="copyright">
                <p>Copyright © Developed by <a href="">Amani R Leoni </a> 2021-<?php echo date("Y");?></p>
            </div>
        </div>