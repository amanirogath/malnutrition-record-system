<?php
session_start();

$message="";
require("conn.php");
if(isset($_POST['gogo'])){
$user=mysqli_real_escape_string($connect,trim(htmlspecialchars($_POST['email'])));
$pass=mysqli_real_escape_string($connect,trim(htmlspecialchars($_POST['pass'])));

$cal="SELECT `special_id`,`first`,`email`,`password`,`status` FROM `users` WHERE `email`='$user'";
$ly=mysqli_query($connect,$cal);
$cou=mysqli_num_rows($ly);

if($cou>0){
$ff=mysqli_fetch_array($ly);
$spec=$ff['special_id'];
$user=$ff['email'];
$nm=$ff['first'];
$sst=$ff['status'];

$pasy=$ff['password'];

$ver=password_verify($pass,$pasy);

if($ver){

    $_SESSION['identity']=$spec;
    $_SESSION['name']=$nm;
    $_SESSION['stat']=$sst;

//start log
$arr_browsers = ["Opera", "Edg", "Chrome", "Safari", "Firefox", "MSIE", "Trident"];
 
$agent = $_SERVER['HTTP_USER_AGENT'];
 
$user_browser = '';
foreach ($arr_browsers as $browser) {
    if (strpos($agent, $browser) !== false) {
        $user_browser = $browser;
        break;
    }   
}
  
switch ($user_browser) {
    case 'MSIE':
        $user_browser = 'Internet Explorer';
        break;
  
    case 'Trident':
        $user_browser = 'Internet Explorer';
        break;
  
    case 'Edg':
        $user_browser = 'Microsoft Edge';
        break;
}

$aidi=$spec;
$dat=date('d-m-Y');
$time=date("h:i:sa");
$stat="login";
   $inj="INSERT INTO `log`(`user_id`, `date`, `time`, `status`,`browser`) value('$aidi','$dat','$time','$stat','$user_browser')";
    $ins=mysqli_query($connect,$inj);

//end log


    $message="<div class='alert alert-success alert-dismissible fade show'>
    <svg viewBox='0 0 24 24' width='24' height='24' stroke='currentColor' stroke-width='2' fill='none' stroke-linecap='round' stroke-linejoin='round' class='mr-2'><polyline points='9 11 12 14 22 4'></polyline><path d='M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11'></path></svg>	
    <strong>Login Success</strong>.
    <button type='button' class='close h-100' data-dismiss='alert' aria-label='Close'><span><i class='fas-fa times'></i></span>
    </button>
</div>";
header("location:dashboard.php");
}
else{
    $message="<div class='alert alert-warning alert-dismissible fade show'>
    <svg viewBox='0 0 24 24' width='24' height='24' stroke='currentColor' stroke-width='2' fill='none' stroke-linecap='round' stroke-linejoin='round' class='mr-2'><path d='M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z'></path><line x1='12' y1='9' x2='12' y2='13'></line><line x1='12' y1='17' x2='12.01' y2='17'></line></svg>
	 <strong>Password dosen't match</strong>.
    <button type='button' class='close h-100' data-dismiss='alert' aria-label='Close'><span><i class='mdi mdi-close'></i></span>
    </button>
</div>";
}
}
else{
    $message="<div class='alert alert-warning alert-dismissible fade show'>
    <svg viewBox='0 0 24 24' width='24' height='24' stroke='currentColor' stroke-width='2' fill='none' stroke-linecap='round' stroke-linejoin='round' class='mr-2'><path d='M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z'></path><line x1='12' y1='9' x2='12' y2='13'></line><line x1='12' y1='17' x2='12.01' y2='17'></line></svg>
	 <strong>Username dosen't exist</strong>.
    <button type='button' class='close h-100' data-dismiss='alert' aria-label='Close'><span><i class='mdi mdi-close'></i></span>
    </button>
</div>";   
}
}

?>
<!DOCTYPE html>
<html lang="en" class="h-100">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>login</title>
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="images/favicon.png">
    <link href="css/style.css" rel="stylesheet">

</head>

<body class="h-100">
    <div class="authincation h-100">
        <div class="container h-100">
            <div class="row justify-content-center h-100 align-items-center">
                <div class="col-md-6">
                    <div class="authincation-content">
                        <div class="row no-gutters">
                            <div class="col-xl-12">
                                <div class="auth-form">
                                <bold><h3 class="text-center mb-4">M.R.S</h3></bold>
                                    <h4 class="text-center mb-4">Sign in to your account</h4>
                                    <form method="POST">
                                        <div class="form-group">
                                            <label class="mb-1"><strong>Email</strong></label>
                                            <input type="email" name="email" required="required" class="form-control" placeholder="Enter email">
                                        </div>
                                        <div class="form-group">
                                            <label class="mb-1"><strong>Password</strong></label>
                                            <input type="password" name="pass" required="required" class="form-control" placeholder="Re-enter Password">
                                        </div>
                                        <div class="form-row d-flex justify-content-between mt-4 mb-2">
                                            <div class="form-group">
                                               <div class="custom-control custom-checkbox ml-1">
													<input type="checkbox" class="custom-control-input" id="basic_checkbox_1">
													<label class="custom-control-label" for="basic_checkbox_1">Remember my preference</label>
												</div>
                                            </div>
                                            <div class="form-group">
                                                <a href="reset.php">Forgot Password?</a>
                                            </div>
                                        </div>
                                        <?php echo $message; ?>
                                            
                                        <div class="text-center">
                                            <button type="submit" name="gogo" class="btn btn-success btn-block">Sign Me In</button>
                                        </div>
                                    </form>
                                    <div class="new-account mt-3">
                                        <p>Don't have an account? <a class="text-primary" href="register.php">Sign up</a></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <!--**********************************
        Scripts
    ***********************************-->
    <!-- Required vendors -->
    <script src="vendor/global/global.min.js"></script>
	<script src="vendor/bootstrap-select/dist/js/bootstrap-select.min.js"></script>
    <script src="js/custom.min.js"></script>
    <script src="js/deznav-init.js"></script>

</body>

</html>