<?php
require('../fpdf.php');
$name="Ahaaaaaaaaaaaa";
$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial','B',16);
$pdf->Cell(90,10,$name,0);
$pdf->Cell(90,10,'Hello World!',0);
$pdf->Output();
?>
