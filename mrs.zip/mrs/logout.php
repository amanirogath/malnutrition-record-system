<?php
session_start();
require('conn.php');
//start log
$arr_browsers = ["Opera", "Edg", "Chrome", "Safari", "Firefox", "MSIE", "Trident"];
 
$agent = $_SERVER['HTTP_USER_AGENT'];
 
$user_browser = '';
foreach ($arr_browsers as $browser) {
    if (strpos($agent, $browser) !== false) {
        $user_browser = $browser;
        break;
    }   
}
  
switch ($user_browser) {
    case 'MSIE':
        $user_browser = 'Internet Explorer';
        break;
  
    case 'Trident':
        $user_browser = 'Internet Explorer';
        break;
  
    case 'Edg':
        $user_browser = 'Microsoft Edge';
        break;
}

$aidi=$_SESSION['identity'];
$dat=date('d-m-Y');
$time=date("h:i:sa");
$stat="logout";
   $inj="INSERT INTO `log`(`user_id`, `date`, `time`, `status`,`browser`) value('$aidi','$dat','$time','$stat','$user_browser')";
    $ins=mysqli_query($connect,$inj);

//end log

session_destroy();
header("location:index.php");
?>