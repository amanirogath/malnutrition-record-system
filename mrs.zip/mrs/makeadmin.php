<?php
session_start();
include('conn.php');
$ki=$_GET['key'];


$g=$_SESSION['stat'];

if($g=="ADMIN"){
                       
   
$re="UPDATE `users` SET `status`='ADMIN' WHERE `special_id`='$ki'";
$er=mysqli_query($connect,$re);
if($er){
header('location:viewstaff.php');

}
{
    echo "cannot update status";
}

}
else{
    die();
  }
?>