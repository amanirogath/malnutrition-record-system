<?php
session_start();
include('conn.php');
if(empty($_SESSION['identity'])){
    header("location:index.php");
    die();
}

$aidi=$_GET['key'];
if(isset($_POST['fnd'])){
	header("location:result.php");
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Dashboard</title>
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="images/favicon.png">
    <link href="vendor/jqvmap/css/jqvmap.min.css" rel="stylesheet">
	<link rel="stylesheet" href="vendor/chartist/css/chartist.min.css">
    <link href="vendor/bootstrap-select/dist/css/bootstrap-select.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
	<link href="../../cdn.lineicons.com/2.0/LineIcons.css" rel="stylesheet">

</head>
<body>

 
<?php include("topbar.php");?>
        
       
        <!--**********************************
            Sidebar start
        ***********************************-->
        <?php

        $g=$_SESSION['stat'];
        
        if($g=="ADMIN"){
            include("sidebar.php");


								}
								else{
                                    include("userside.php");
								}

                                ?>
        <!--**********************************
            Sidebar end
        ***********************************-->
		
		<!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">
            <!-- row -->
			<div class="container-fluid">
				<div class="form-head d-flex mb-3 align-items-start">
					<div class="mr-auto d-none d-lg-block">
						<h2 class="text-black font-w600 mb-0">More Metrics Information</h2>
					
					</div>
					
					
				</div>
            
				
                <div class="row">
                    <div class="col-lg-12">
                        
 <?php
 $re="SELECT * FROM `children` WHERE `special_id`='$aidi'";
$er=mysqli_query($connect,$re);

$fe=mysqli_fetch_array($er);


$dre="SELECT * FROM `rehabilitation` WHERE `child_id`='$aidi'";
$der=mysqli_query($connect,$dre);

$dfe=mysqli_fetch_array($der);

?>

                

<div class="card">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-xl-3 ">
                                        <!-- Tab panes -->
                                        <div class="tab-content">
                                            <div role="tabpanel" class="tab-pane fade show active" id="first">
                                                <img class="img-fluid" src="<?php echo $fe['photo'];?>" alt="">
                                            </div>
                                           
                                        </div>
                                        <div class="tab-slide-content new-arrival-product mb-4 mb-xl-0">
                                            
                                        </div>
                                    </div>
                                    <!--Tab slider End-->
                                    <div class="col-xl-9 col-sm-12">
                                        <div class="product-detail-content">
                                            <!--Product details-->
                                            <div class="new-arrival-content pr">
                                                <h4><?php echo $fe['full_name'];?></h4>
                                              
                                                <p class="price"><?php echo $fe['gender'];?></p>
                                            
                                                <p>Date Of Birth: <span class="item"><?php echo $fe['dob'];?></span> </p>
                                                <p>Cotact: <span class="item"><?php echo $fe['contacts'];?></span></p>
                                                <p>Address: <span class="item"><?php echo $fe['address'];?></span></p>
                                                <p>Nationality: <span class="item"><?php echo $fe['nationality'];?></span></p>
                                                <!-- <p>Status:&nbsp;&nbsp;
                                                    <span class="badge badge-success light"><?php //echo $dfe['status'];?></span> -->
                                                   
                                                </p>
                                                <p>Observation: <span class="item"><?php echo $dfe['observation'];?></span></p>
                                                <!-- <p>Start Date: <span class="item"><?php // echo $dfe['date_start'];?></span></p>
                                                <p>End Date: <span class="item"><?php //echo $dfe['date_end'];?></span></p> -->
                                                

											
                                            </div>
                                        </div>



                                        

                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                            
                    </div>

                    <div class="card">
                            <div class="card-header">
                                <h4 class="card-title">Screening Records</h4>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-responsive-md">
                                        <thead>
                                            <tr>
                                                <th style="width:80px;"><strong>#</strong></th>
                                                <th><strong>DATE</strong></th>
                                                <th><strong>HEIGHT</strong></th>
                                                <th><strong>WEIGHT</strong></th>
                                                <th><strong>MUAC</strong></th>
                                                <th><strong>TEMPERETURE</strong></th>
                                                <th><strong>OBSERVATION</strong></th>
                                            </tr>
                                        </thead>
                                        <tbody>

 <?php

//  SELECT `id`, `child_id`, `date`, `height`, `weight`, `muac`, `temperature`, 
//  `observation`, `status`, `staff_id`, `comment`, `location_id` FROM `records` WHERE 1

 $rfe="SELECT * FROM `records` WHERE `child_id`='$aidi' AND `status`='OPD'";
$efr=mysqli_query($connect,$rfe);

$s=1;

while ($ffe=mysqli_fetch_array($efr)) {
 
 echo '<tr>';
 echo '<td>'.$s.'</td>';
 echo '<td><strong>'.$ffe['date'].'</strong></td>';
 echo '<td>'.$ffe['height'].'</td>';
 echo '<td>'.$ffe['weight'].'</td>';
 echo '<td>'.$ffe['muac'].'</td>';
 echo '<td>'.$ffe['temperature'].'</td>';
 echo '<td>'.$ffe['observation'].'</td>';
 echo'</tr>';
 $s++;
}
?>

                
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>

                </div>
				
				 </div>
            
        </div>
        <!--**********************************
            Content body end
        ***********************************-->

        <!--**********************************
            Footer start
        ***********************************-->
        <div class="footer">
            <div class="copyright">
                <p>Copyright © Developed by <a href="">Amani R Leoni </a> 2021-<?php echo date("Y");?></p>
            </div>
        </div>
        <!--**********************************
            Footer end
        ***********************************-->

		<!--**********************************
           Support ticket button start
        ***********************************-->

        <!--**********************************
           Support ticket button end
        ***********************************-->


    </div>
    <!--**********************************
        Main wrapper end
    ***********************************-->

    <!--**********************************
        Scripts
    ***********************************-->
    <!-- Required vendors -->
    <script src="vendor/global/global.min.js"></script>
	<script src="vendor/bootstrap-select/dist/js/bootstrap-select.min.js"></script>
	<script src="vendor/chart.js/Chart.bundle.min.js"></script>
    <script src="js/custom.min.js"></script>
	<script src="js/deznav-init.js"></script>
	
	<!-- Counter Up -->
    <script src="vendor/waypoints/jquery.waypoints.min.js"></script>
    <script src="vendor/jquery.counterup/jquery.counterup.min.js"></script>	
		
	<!-- Apex Chart -->
	<script src="vendor/apexchart/apexchart.js"></script>	
	
	<!-- Chart piety plugin files -->
	<script src="vendor/peity/jquery.peity.min.js"></script>
	
	<!-- Dashboard 1 -->
	<script src="js/dashboard/dashboard-1.js"></script>
	
	
</body>

</html>