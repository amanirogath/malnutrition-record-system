<?php
session_start();
include('conn.php');

$message="";
if(empty($_SESSION['identity'])){
    header("location:index.php");
    die();
}


if(isset($_POST['fnd'])){
	header("location:result.php");
}

$aidi=$_SESSION['identity'];



if(isset($_POST['info'])){
    $first=$_POST['fname'];
    $last=$_POST['lname'];
    $age=$_POST['age'];
    $email=$_POST['email'];
  
    $imagee = $_FILES['images']['name'];
    $upd = "images/profile/".basename($imagee);
     move_uploaded_file($_FILES['images']['tmp_name'], $upd);

$zam="UPDATE `users` SET `first`='$first',`last`='$last',`age`='$age',`email`='$email',`photo`='$upd' WHERE `special_id`='$aidi'";
 
 $isha=mysqli_query($connect,$zam);
 
 if($isha){

    $message="<div class='alert alert-success alert-dismissible fade show'>
    <svg viewBox='0 0 24 24' width='24' height='24' stroke='currentColor' stroke-width='2' fill='none' stroke-linecap='round' stroke-linejoin='round' class='mr-2'><polyline points='9 11 12 14 22 4'></polyline><path d='M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11'></path></svg>	
    <strong>Successfuly updated!</strong>.
    <button type='button' class='close h-100' data-dismiss='alert' aria-label='Close'><span><i class='fas-fa times'></i></span>
    </button>
</div>";
}
else{
    $message="<div class='alert alert-warning alert-dismissible fade show'>
    <svg viewBox='0 0 24 24' width='24' height='24' stroke='currentColor' stroke-width='2' fill='none' stroke-linecap='round' stroke-linejoin='round' class='mr-2'><path d='M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z'></path><line x1='12' y1='9' x2='12' y2='13'></line><line x1='12' y1='17' x2='12.01' y2='17'></line></svg>
	 <strong>cannot update</strong>.
    <button type='button' class='close h-100' data-dismiss='alert' aria-label='Close'><span><i class='mdi mdi-close'></i></span>
    </button>
</div>";
}
}

$re="SELECT * FROM `users` WHERE `special_id`='$aidi'";
$er=mysqli_query($connect,$re);
$fe=mysqli_fetch_array($er);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Dashboard</title>
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="images/favicon.png">
    <link href="vendor/jqvmap/css/jqvmap.min.css" rel="stylesheet">
	<link rel="stylesheet" href="vendor/chartist/css/chartist.min.css">
    <link href="vendor/bootstrap-select/dist/css/bootstrap-select.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
	<link href="../../cdn.lineicons.com/2.0/LineIcons.css" rel="stylesheet">

</head>
<body>

<?php include("topbar.php");?>
        
       
        <!--**********************************
            Sidebar start
        ***********************************-->
        <?php

$g=$_SESSION['stat'];

if($g=="ADMIN"){
    include("sidebar.php");
                        }
                        else{
                            include("userside.php");
                        }

                        ?>
     
        <!--**********************************
            Sidebar end
        ***********************************-->
		
		<!--**********************************
            Content body start
        ***********************************-->
      
        <div class="content-body">
            <div class="container-fluid">
                <div class="row page-titles mx-0">
                    <div class="col-sm-6 p-md-0">
                        <div class="welcome-text">
                            <h4>My Profile</h4>
                            <p class="mb-0"></p>
                        </div>
                    </div>
                    
                </div>
                <!-- row -->
                <div class="row">
                    <div class="col-lg-12">
                        <div class="profile card card-body px-3 pt-3 pb-0">
                            <div class="profile-head">
                                <div class="photo-content">
                                    <div class="cover-photo"></div>
                                </div>
                                <div class="profile-info">
									<div class="profile-photo">
										<img src="<?php echo $fe['photo'];?>" class="img-fluid rounded-circle" alt="">
									</div>
									<div class="profile-details">
										<div class="profile-name px-3 pt-2">
                                            
											<h4 class="text-primary mb-0" style="text-style:capitalize;"><?php echo $fe['first'].' '.$fe['last'];?></h4>
											<p><?php echo $fe['status'];?></p>
										</div>
										<div class="profile-email px-2 pt-2">
											<h4 class="text-muted mb-0"><?php echo $fe['email'];?></h4>
											<p>Email</p>
										</div>
										
									</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
           
                    <div class="col-xl-12">
                        <div class="card">
                            <div class="card-body">
              
                                                
                                                    <div class="pt-4 border-bottom-1 pb-3">
                                                        <h4 class="text-success">Please Edit Your information Bellow</h4>
                                                         </div>
                                                
                                                <div class="settings-form">
                                                        <form method="POST" enctype="multipart/form-data">
                            <?php echo $message; ?>

                                                            <div class="form-row">

                                                                <div class="form-group col-md-6">
                                                                    <label>First Name</label>
                                                                    <input type="text" placeholder="First Name" class="form-control" name="fname" value="<?php echo $fe['first'];?>">
                                                                </div>
                                                                <div class="form-group col-md-6">
                                                                    <label>Last Name</label>
                                                                    <input type="text" placeholder="Last Name" class="form-control" name="lname"value="<?php echo $fe['last'];?>">
                                                                </div>
                                                                <div class="form-group col-md-6">
                                                                    <label>Email</label>
                                                                    <input type="email" placeholder="Email" class="form-control" name="email"value="<?php echo $fe['email'];?>">
                                                                </div> 
                                                                <div class="form-group col-md-6">
                                                                    <label>Age</label>
                                                                    <input type="text" placeholder="Age" class="form-control" name="age" value="<?php echo $fe['age'];?>">
                                                                </div> 

                                                                <div class="form-group col-md-6">
                                                                <label>Photo</label>
                                            <div class="custom-file">
                                                <input type="file" name="images" class="custom-file-input">
                                                <label class="custom-file-label">Choose file</label>
                                            </div>
                                        </div>
                                                            </div>
                                                            
                                                     
                                                            <button class="btn btn-success" type="submit" name="info">Change My Information</button>
                                                        </form>
                                                    </div>
                                            

                                          
                                        
                                    
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--**********************************
            Content body end
        ***********************************-->

        <!--**********************************
            Footer start
        ***********************************-->
        <div class="footer">
            <div class="copyright">
                <p>Copyright © Developed by <a href="">Amani R Leoni </a> 2021-<?php echo date("Y");?></p>
            </div>
        </div>
        <!--**********************************
            Footer end
        ***********************************-->

		<!--**********************************
           Support ticket button start
        ***********************************-->

        <!--**********************************
           Support ticket button end
        ***********************************-->


    </div>
    <!--**********************************
        Main wrapper end
    ***********************************-->

    <!--**********************************
        Scripts
    ***********************************-->
    <!-- Required vendors -->
    <script src="vendor/global/global.min.js"></script>
	<script src="vendor/bootstrap-select/dist/js/bootstrap-select.min.js"></script>
	<script src="vendor/chart.js/Chart.bundle.min.js"></script>
    <script src="js/custom.min.js"></script>
	<script src="js/deznav-init.js"></script>
	
	<!-- Counter Up -->
    <script src="vendor/waypoints/jquery.waypoints.min.js"></script>
    <script src="vendor/jquery.counterup/jquery.counterup.min.js"></script>	
		
	<!-- Apex Chart -->
	<script src="vendor/apexchart/apexchart.js"></script>	
	
	<!-- Chart piety plugin files -->
	<script src="vendor/peity/jquery.peity.min.js"></script>
	
	<!-- Dashboard 1 -->
	<script src="js/dashboard/dashboard-1.js"></script>
	
	
</body>

</html>