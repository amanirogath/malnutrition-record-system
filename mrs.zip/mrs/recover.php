<?php
session_start();
$who=$_GET['key'];
$message="";
require("conn.php");
if(isset($_POST['gogo'])){
    
    $new=$_POST['pass'];
    $ret=$_POST['repass'];
   
    if($new==$ret){
        $hash=password_hash($new,PASSWORD_DEFAULT);

    
    $zam="UPDATE `users` SET `password`='$hash' WHERE `special_id`='$who'";
 
    $isha=mysqli_query($connect,$zam);

if($isha){

    $message="<div class='alert alert-success alert-dismissible fade show'>
    <svg viewBox='0 0 24 24' width='24' height='24' stroke='currentColor' stroke-width='2' fill='none' stroke-linecap='round' stroke-linejoin='round' class='mr-2'><polyline points='9 11 12 14 22 4'></polyline><path d='M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11'></path></svg>	
    <strong>password have been changed Successful</strong>.
    <button type='button' class='close h-100' data-dismiss='alert' aria-label='Close'><span><i class='fas-fa times'></i></span>
    </button>
</div>";
header("location:index.php");
}
else{
    $message="<div class='alert alert-warning alert-dismissible fade show'>
    <svg viewBox='0 0 24 24' width='24' height='24' stroke='currentColor' stroke-width='2' fill='none' stroke-linecap='round' stroke-linejoin='round' class='mr-2'><path d='M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z'></path><line x1='12' y1='9' x2='12' y2='13'></line><line x1='12' y1='17' x2='12.01' y2='17'></line></svg>
	 <strong>cannot update your password</strong>.
    <button type='button' class='close h-100' data-dismiss='alert' aria-label='Close'><span><i class='mdi mdi-close'></i></span>
    </button>
</div>";
}
}
else{
    $message="<div class='alert alert-warning alert-dismissible fade show'>
    <svg viewBox='0 0 24 24' width='24' height='24' stroke='currentColor' stroke-width='2' fill='none' stroke-linecap='round' stroke-linejoin='round' class='mr-2'><path d='M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z'></path><line x1='12' y1='9' x2='12' y2='13'></line><line x1='12' y1='17' x2='12.01' y2='17'></line></svg>
	 <strong>password dosen't match</strong>.
    <button type='button' class='close h-100' data-dismiss='alert' aria-label='Close'><span><i class='mdi mdi-close'></i></span>
    </button>
</div>";   
}
}

?>
<!DOCTYPE html>
<html lang="en" class="h-100">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>login</title>
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="images/favicon.png">
    <link href="css/style.css" rel="stylesheet">

</head>

<body class="h-100">
    <div class="authincation h-100">
        <div class="container h-100">
            <div class="row justify-content-center h-100 align-items-center">
                <div class="col-md-6">
                    <div class="authincation-content">
                        <div class="row no-gutters">
                            <div class="col-xl-12">
                                <div class="auth-form">
                                <bold><h3 class="text-center mb-4">M.R.S</h3></bold>
                                    <h4 class="text-center mb-4">Recover Password</h4>
                                    <form method="POST">
                                      
                                        <div class="form-group">
                                            <label class="mb-1"><strong>Password</strong></label>
                                            <input type="password" name="pass" required="required" class="form-control" placeholder="Enter Password">
                                        </div>
                                        <div class="form-group">
                                            <label class="mb-1"><strong>Re-enter Password</strong></label>
                                            <input type="password" name="repass" required="required" class="form-control" placeholder="Re-enter Password">
                                        </div>
                                       
                                        <?php echo $message; ?>
                                            
                                        <div class="text-center">
                                            <button type="submit" name="gogo" class="btn btn-success btn-block">Change</button>
                                        </div>
                                    </form>
                                 
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <!--**********************************
        Scripts
    ***********************************-->
    <!-- Required vendors -->
    <script src="vendor/global/global.min.js"></script>
	<script src="vendor/bootstrap-select/dist/js/bootstrap-select.min.js"></script>
    <script src="js/custom.min.js"></script>
    <script src="js/deznav-init.js"></script>

</body>

</html>