<?php
// $message="";
$message="<div class='alert alert-info alert-dismissible fade show'>
    <svg viewBox='0 0 24 24' width='24' height='24' stroke='currentColor' stroke-width='2' fill='none' stroke-linecap='round' stroke-linejoin='round' class='mr-2'><polyline points='9 11 12 14 22 4'></polyline><path d='M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11'></path></svg>	
    <strong>Contact Admin</strong> For Registration!.
    <button type='button' class='close h-100' data-dismiss='alert' aria-label='Close'><span><i class='fas-fa times'></i></span>
    </button>
</div>";
require("conn.php");
if(isset($_POST['send'])){
    $first=$_POST['first'];
    $last=$_POST['last'];
    $age=$_POST['age'];
    $email=$_POST['email'];
    $pass=$_POST['pass'];
    $repass=$_POST['repass'];
    
    $sh=str_shuffle("ABCDEFGHIJabcdefghij1234567890");
if($pass==$repass){
    $hu=password_hash($pass,PASSWORD_DEFAULT);
 $zam="INSERT INTO `users`(`special_id`, `first`, `last`, `age`, `email`, `password`) 
 VALUES ('$sh','$first','$last','$age','$email','$hu')";
 
 $isha=mysqli_query($connect,$zam);
 
 if($isha){

    $message="<div class='alert alert-success alert-dismissible fade show'>
    <svg viewBox='0 0 24 24' width='24' height='24' stroke='currentColor' stroke-width='2' fill='none' stroke-linecap='round' stroke-linejoin='round' class='mr-2'><polyline points='9 11 12 14 22 4'></polyline><path d='M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11'></path></svg>	
    <strong>Successfuly Registered!</strong> Please sign in .
    <button type='button' class='close h-100' data-dismiss='alert' aria-label='Close'><span><i class='fas-fa times'></i></span>
    </button>
</div>";
 }
else{
    $message="<div class='alert alert-warning alert-dismissible fade show'>
    <svg viewBox='0 0 24 24' width='24' height='24' stroke='currentColor' stroke-width='2' fill='none' stroke-linecap='round' stroke-linejoin='round' class='mr-2'><path d='M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z'></path><line x1='12' y1='9' x2='12' y2='13'></line><line x1='12' y1='17' x2='12.01' y2='17'></line></svg>
	 <strong>Data cannot be inserted</strong>.
    <button type='button' class='close h-100' data-dismiss='alert' aria-label='Close'><span><i class='mdi mdi-close'></i></span>
    </button>
</div>";
}
}
else{
    $message="<div class='alert alert-warning alert-dismissible fade show'>
    <svg viewBox='0 0 24 24' width='24' height='24' stroke='currentColor' stroke-width='2' fill='none' stroke-linecap='round' stroke-linejoin='round' class='mr-2'><path d='M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z'></path><line x1='12' y1='9' x2='12' y2='13'></line><line x1='12' y1='17' x2='12.01' y2='17'></line></svg>
	 <strong>Password dosen't match</strong>.
    <button type='button' class='close h-100' data-dismiss='alert' aria-label='Close'><span><i class='mdi mdi-close'></i></span>
    </button>
</div>";
}
}
?>

<!DOCTYPE html>
<html lang="en" class="h-100">


<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title></title>
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="images/favicon.png">
    <link href="css/style.css" rel="stylesheet">
    <link href="lib/fontawesome/all.css" rel="stylesheet">
    <link href="lib/fontawesome/all.min.css" rel="stylesheet">
    <link href="lib/fontawesome/fontawesome.css" rel="stylesheet">
    <link href="lib/fontawesome/fontawesome.min.css" rel="stylesheet">
    <link href="lib/fontawesome/solid.css" rel="stylesheet">
    <link href="lib/fontawesome/solid.min.css" rel="stylesheet">

</head>

<body class="h-100">
    <div class="authincation h-100">
        <div class="container h-100">
            <div class="row justify-content-center h-100 align-items-center">
                <div class="col-md-6">
                    <div class="authincation-content">
                        <div class="row no-gutters">
                            <div class="col-xl-12">
                                <div class="auth-form">
                                    <h4 class="text-center mb-4">Sign up your account</h4>
                                    <form method="POST">

                                        <!-- <div class="form-group">
                                            <label class="mb-1"><strong>First Name</strong></label>
                                            <input type="text" name="first" required="required" class="form-control" placeholder="First Name">
                                        </div>
                                        <div class="form-group">
                                            <label class="mb-1"><strong>Last Name</strong></label>
                                            <input type="text" name="last"required="required" class="form-control" placeholder="Last Name">
                                        </div>  <div class="form-group">
                                            <label class="mb-1"><strong>Age</strong></label>
                                            <input type="number" name="age" required="required" class="form-control" placeholder="Age">
                                        </div>
                                        <div class="form-group">
                                            <label class="mb-1"><strong>Email</strong></label>
                                            <input type="email" name="email" required="required" class="form-control" placeholder="email">
                                        </div>
                                        <div class="form-group">
                                            <label class="mb-1"><strong>Password</strong></label>
                                            <input type="password" name="pass" required="required" class="form-control" placeholder="Password">
                                        </div>
                                        <div class="form-group">
                                            <label class="mb-1"><strong>Re - Password</strong></label>
                                            <input type="password" name="repass" required="required" class="form-control" placeholder="Retype Password">
                                        </div> -->
                                       <?php echo $message;?>
                                        <div class="text-center mt-4">
                                            <button type="submit" name="send" class="btn btn-success btn-block" disabled="disabled">Sign me up</button>
                                        </div>
                                    </form>
                                    <div class="new-account mt-3">
                                        <p>Already have an account? <a class="text-primary" href="index.php">Sign in</a></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<!--**********************************
	Scripts
***********************************-->
<!-- Required vendors -->
<script src="vendor/global/global.min.js"></script>
<script src="vendor/bootstrap-select/dist/js/bootstrap-select.min.js"></script>
<script src="js/custom.min.js"></script>
<script src="js/deznav-init.js"></script>

</body>

</html>