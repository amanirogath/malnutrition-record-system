<?php
session_start();

$a=$_SESSION['day1'];
$b=$_SESSION['day2'];
 // $re="SELECT * FROM `transaction` WHERE date1 BETWEEN '$a' AND '$b'";

 date_default_timezone_set('Africa/Dar_es_Salaam');

  $br=date("Y-m-d");


  require_once("conn.php");
  require_once("lib/fpdf/fpdf.php");
  $pdf = new FPDF('L','mm','A4');
  $pdf->addpage();
  
  $pdf->SetTextColor(43, 193,85);
  $pdf->SetFont('Arial','B',16);
  // $x=30;
  // $y=40;
  // $pdf->setX($x);
  // $pdf->setY($y);
  $pdf->Cell(80,10,'Malnutrition Record System',0,1);
  $pdf->Cell(80,10,$a,0,0);
  $pdf->Cell(80,10,$b,0,1);
  $pdf->Cell(40,10,'screening report',0,1);
  // $x=$x+90;
  // $y=$y+5;
  // $pdf->setX($x);
  // $pdf->setY($y);
  $pdf->Cell(20,10,'N/O',0,0);
  $pdf->Cell(100,10,'NAME',0,0);
  $pdf->Cell(30,10,'HEIGHT',0,0);
  $pdf->Cell(30,10,'WEIGHT',0,0);
  $pdf->Cell(30,10,'MUAC',0,0);
  $pdf->Cell(30,10,'TEMP',0,0);
  $pdf->Cell(30,10,'STATUS',0,1);
  
  $pdf->SetTextColor(0,0,0);
  
  
  //generated date
  $gdt=date('d-m-Y');
  
  
//   $sql="SELECT * FROM  `records` WHERE `status`='OPD' AND `date`='$gdt'";
  $sql="SELECT * FROM `records` WHERE `date` BETWEEN '$a' AND '$b' ORDER BY `id` DESC";

  $vfn=mysqli_query($connect,$sql);
  $num=1;
  while ($fn=mysqli_fetch_array($vfn))
   {
      $em=$fn['child_id'];
      $hd=$fn['height'];
      $us=$fn['weight'];
      $ag=$fn['muac'];
      $at=$fn['temperature'];
      $as=$fn['status'];
  
  //child name
  
  $kd="SELECT * FROM `children` WHERE `special_id`='$em'";
  $kdf=mysqli_query($connect,$kd);
  $kdd=mysqli_fetch_array($kdf);
      $emn=$kdd['full_name'];
  // $x=30;
  // $y=$y+40;
  // $pdf->setX($x);
  // $pdf->setY($y);
  $pdf->SetFont('Arial','',12);
  // $pdf->setX($x);
  // $pdf->setY($y);
  $pdf->cell(20,10,$num,1,0,'C');
  // $x=$x+40;
  // $pdf->setX($x);
  // $pdf->setY($y);
  $pdf->cell(100,10,$emn,1,0,'c');
  // $y=$y+30;
  // $x=$x+40;
  // $pdf->setX($x);
  // $pdf->setY($y);
  $pdf->cell(30,10,$hd,1,0,'c');
  // $x=$x+40;
  // $pdf->setX($x);
  // $pdf->setY($y);
  $pdf->cell(30,10,$us,1,0,'c');
  // $x=$x+40;
  // $pdf->setX($x);
  // $pdf->setY($y);
  $pdf->cell(30,10,$ag,1,0,'c');
  
  $pdf->cell(30,10,$at,1,0,'c');
  
  $pdf->cell(30,10,$as,1,1,'c');
  $num++;
  }
  // query(query)
  // connection
  
  
  $pdf->output();
  
  ?>
  <!DOCTYPE html>
  <html lang="en">
  <head>
      <meta charset="UTF-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Report PDF daily</title>
  </head>
  <body>
      
  </body>
  </html>