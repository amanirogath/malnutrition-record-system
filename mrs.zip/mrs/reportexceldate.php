<?php
session_start();

$a=$_SESSION['day1'];
$b=$_SESSION['day2'];
 // $re="SELECT * FROM `transaction` WHERE date1 BETWEEN '$a' AND '$b'";

 date_default_timezone_set('Africa/Dar_es_Salaam');

  $br=date("Y-m-d");

//   $re="SELECT * FROM `cust_transaction` WHERE `date` BETWEEN '$a' AND '$b' AND `status`!='KUKOPA' AND `status`!='PENATI' ORDER BY `id` DESC";
  $re="SELECT * FROM `records` WHERE `date` BETWEEN '$a' AND '$b' ORDER BY `id` DESC";


  require_once('conn.php');

  require_once 'lib/Classes/PHPExcel.php';
  require_once 'lib/Classes/PHPExcel/Writer/Excel2007.php';
  require_once 'lib/Classes/PHPExcel/IOFactory.php';
  //database connection
  $con = mysqli_connect("localhost","root","","mrs");
  
  // $date=date("Y-m-d");
  // $re=date('d-m-Y', strtotime($b. '+ $dh days'));
  
  //Creation PHPExcel Object	
  $excel = new PHPExcel();
  //selecting active sheet
      
  $excel->setActiveSheetIndex(0);
  //populate data
  $tod=date("d-m-Y");
  
  //failed to separate wa zamani na wasasa
  // AND days_remain=''
  // $sql="SELECT * FROM  `rehabilitation`";
  // $vfn=mysqli_query($connect,$sql);
  // $num=1;
  // while ($fn=mysqli_fetch_array($vfn))
  //  {
  // 	$em=$fn['child_id'];
  // 	$hd=$fn['center_id'];
  //     $as=$fn['status'];
  //     $us=$fn['user'];
  
  
  $query = mysqli_query($connect,"SELECT * FROM `rehabilitation` WHERE `date_start`='$tod'");
  $row = 4;
  while ($data = mysqli_fetch_object($query)){
      $excel->getActiveSheet()
      ->setCellValue('A'.$row, $data->child_id)
      ->setCellValue('B'.$row, $data->height)
      ->setCellValue('C'.$row, $data->weight)
      ->setCellValue('D'.$row, $data->muac)
      ->setCellValue('E'.$row, $data->temp)
      ->setCellValue('F'.$row, $data->status);
  
  $row++;
  }
  //set column width
  $excel->getActiveSheet()->getColumnDimension('A')->setWidth(60);
  $excel->getActiveSheet()->getColumnDimension('B')->setWidth(60);
  $excel->getActiveSheet()->getColumnDimension('C')->setWidth(20);
  $excel->getActiveSheet()->getColumnDimension('D')->setWidth(20);
  $excel->getActiveSheet()->getColumnDimension('E')->setWidth(20);
  $excel->getActiveSheet()->getColumnDimension('F')->setWidth(20);
  // $excel->getActiveSheet()->getColumnDimension('D')->setWidth(20);
  
  //make table headers
  $excel->getActiveSheet()
 

      ->setCellValue('A1', 'Malnutrition Record System')
      ->setCellValue('A3', 'NAME')
      ->setCellValue('B3', 'HEIGHT')
      ->setCellValue('C3', 'WEIGHT')
      ->setCellValue('D3', 'MUAC')
      ->setCellValue('E3', 'TEMPERETURE')
      ->setCellValue('F3', 'STATUS')
      // ->setCellValue('D3', 'PHONE')
      
      // ->setCellValue('E3', 'USER TYPE')
      // ->setCellValue('F3', 'STATUS')
      ;
  //merging the title
  $excel->getActiveSheet()->mergeCells('A1:C1');
  //alginment
  $excel->getActiveSheet()->getStyle('A1')->getAlignment()->setHorizontal('center');
  $excel->getActiveSheet()->getStyle('A3:F'.($row-1))->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
  $excel->getActiveSheet()->getStyle('A3:F'.($row-1))->getAlignment()->setHorizontal('center');
  
  //STYLE
  $excel->getActiveSheet()->getStyle('A1')->applyFromArray(
      array(
          'font'=>array(
              'size'=>24,
          )
      )
  );
  $excel->getActiveSheet()->getStyle('A3:F3')->applyFromArray(
      array(
          'font'=>array(
              'bold'=>true,
              'size'=>14,
          ),
          'borders'=>array(
              'allborders'=>array(
                  'style'=>PHPExcel_Style_Border::BORDER_THIN
              )
          )
      )
  );
  
  //give borders to data
  $excel->getActiveSheet()->getStyle('A3:F'.($row - 1))->applyFromArray(
      array(
          'borders'=> array(
              'outline'=>array(
                  'style' => PHPExcel_Style_Border::BORDER_THIN
              ),
              'vertical'=>array(
                  'style'=>PHPExcel_Style_Border::BORDER_MEDIUMDASHDOT,
                  'color' => array('rgb' => '2bc155')
              ),
              'allborders'=>array(
                  'style'=>PHPExcel_Style_Border::BORDER_MEDIUM
              )
          ),
          'font'=>array(
                  'name'  => 'calibri'
              )
      )
  );
  $excel->getActiveSheet()->getStyle('A1')->applyFromArray(
      array(
          'fill' => array(
              'type' => PHPExcel_Style_Fill::FILL_SOLID,
              'color' => array('rgb' => '2bc155')
          )
      )
  );
  
  //try auto dimenion
  $excel->getActiveSheet()->getStyle('A3:F3')->getAlignment()->setWrapText(true);
  $excel->getActiveSheet()->getRowDimension(100)->setRowHeight(-1);
  //larger height
  $excel->getActiveSheet()->getStyle('A3:F'.($row-1))->getAlignment()->setWrapText(true);
  $excel->getActiveSheet()->getRowDimension(11)->setRowHeight(-1);
  
  
  //REdirect to bworser for download instead of saving the result as a file
  header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  header('Content-Disposition: attachment; filename="M.R.S '.$a.' -'.$b.' report, printed on '.$tod.'.xlsx"');
  header('Cache-Control: max-age=0');
  
  //write result to a file 
  $file = PHPExcel_IOFactory::createWriter($excel,'Excel2007');
  //output to php outout instead of file name
  $file->save('php://output');
   ?>