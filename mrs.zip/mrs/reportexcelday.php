<?php 
session_start();
// if(empty($_SESSION['email'])){
//     header("location:index.php");
//     die();
// }

require_once('conn.php');

require_once 'lib/Classes/PHPExcel.php';
require_once 'lib/Classes/PHPExcel/Writer/Excel2007.php';
require_once 'lib/Classes/PHPExcel/IOFactory.php';
//database connection
$con = mysqli_connect("localhost","root","","mrs");

// $date=date("Y-m-d");
// $re=date('d-m-Y', strtotime($b. '+ $dh days'));

//Creation PHPExcel Object	
$excel = new PHPExcel();
//selecting active sheet
	
$excel->setActiveSheetIndex(0);
//populate data
$tod=date("d-m-Y");

//failed to separate wa zamani na wasasa
// AND days_remain=''

$query = mysqli_query($connect,"SELECT * FROM `records` WHERE `date`='$tod'");
$row = 4;
while ($data = mysqli_fetch_object($query)){
	$excel->getActiveSheet()
	->setCellValue('A'.$row, $data->child_id)
	->setCellValue('B'.$row, $data->height)
	->setCellValue('C'.$row, $data->status);

$row++;
}
//set column width
$excel->getActiveSheet()->getColumnDimension('A')->setWidth(60);
$excel->getActiveSheet()->getColumnDimension('B')->setWidth(20);
$excel->getActiveSheet()->getColumnDimension('C')->setWidth(20);
// $excel->getActiveSheet()->getColumnDimension('D')->setWidth(20);

//make table headers
$excel->getActiveSheet()
	->setCellValue('A1', 'SCREENED CHILDREN')
	->setCellValue('A3', 'NAME')
	->setCellValue('B3', 'HEIGHT')
	->setCellValue('C3', 'STATUS')
    // ->setCellValue('D3', 'PHONE')
    
	// ->setCellValue('E3', 'USER TYPE')
	// ->setCellValue('F3', 'STATUS')
	;
//merging the title
$excel->getActiveSheet()->mergeCells('A1:C1');
//alginment
$excel->getActiveSheet()->getStyle('A1')->getAlignment()->setHorizontal('center');
$excel->getActiveSheet()->getStyle('A3:C'.($row-1))->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
$excel->getActiveSheet()->getStyle('A3:C'.($row-1))->getAlignment()->setHorizontal('center');

//STYLE
$excel->getActiveSheet()->getStyle('A1')->applyFromArray(
	array(
		'font'=>array(
			'size'=>24,
		)
	)
);
$excel->getActiveSheet()->getStyle('A3:C3')->applyFromArray(
	array(
		'font'=>array(
			'bold'=>true,
			'size'=>14,
		),
		'borders'=>array(
			'allborders'=>array(
				'style'=>PHPExcel_Style_Border::BORDER_THIN
			)
		)
	)
);

//give borders to data
$excel->getActiveSheet()->getStyle('A3:C'.($row - 1))->applyFromArray(
	array(
		'borders'=> array(
			'outline'=>array(
				'style' => PHPExcel_Style_Border::BORDER_THIN
			),
			'vertical'=>array(
				'style'=>PHPExcel_Style_Border::BORDER_MEDIUMDASHDOT,
				'color' => array('rgb' => '2bc155')
			),
			'allborders'=>array(
				'style'=>PHPExcel_Style_Border::BORDER_MEDIUM
			)
		),
		'font'=>array(
				'name'  => 'calibri'
			)
	)
);
$excel->getActiveSheet()->getStyle('A1')->applyFromArray(
    array(
        'fill' => array(
            'type' => PHPExcel_Style_Fill::FILL_SOLID,
            'color' => array('rgb' => '2bc155')
        )
    )
);

//try auto dimenion
$excel->getActiveSheet()->getStyle('A3:C3')->getAlignment()->setWrapText(true);
$excel->getActiveSheet()->getRowDimension(100)->setRowHeight(-1);
//larger height
$excel->getActiveSheet()->getStyle('A3:C'.($row-1))->getAlignment()->setWrapText(true);
$excel->getActiveSheet()->getRowDimension(11)->setRowHeight(-1);


//REdirect to bworser for download instead of saving the result as a file
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment; filename="M.R.S day report'.$tod.'.xlsx"');
header('Cache-Control: max-age=0');

//write result to a file 
$file = PHPExcel_IOFactory::createWriter($excel,'Excel2007');
//output to php outout instead of file name
$file->save('php://output');
 ?>