<?php
require_once("conn.php");
require_once("lib/fpdf/fpdf.php");
$pdf = new FPDF('L','mm','A4');
$pdf->addpage();

$pdf->SetTextColor(43, 193,85);
$pdf->SetFont('Arial','B',16);
// $x=30;
// $y=40;
// $pdf->setX($x);
// $pdf->setY($y);
$dtt=date('Y-m-d');
$pdf->Cell(80,10,'Malnutrition Record System',0,1);
$pdf->Cell(80,10,$dtt,0,1);
$pdf->Cell(40,10,'Brief day rehabilitation center report',0,1);
// $x=$x+90;
// $y=$y+5;
// $pdf->setX($x);
// $pdf->setY($y);
$pdf->Cell(20,10,'N/O',0,0);
$pdf->Cell(60,10,'CHILD',0,0);
$pdf->Cell(60,10,'CENTER',0,0);
$pdf->Cell(40,10,'STATUS',0,0);
$pdf->Cell(50,10,'STARTING DATE',0,0);
$pdf->Cell(50,10,'END DATE',0,1);
$pdf->SetTextColor(0,0,0);
// $x=$x+30;
// $y=$y+5;     
   //food,diagonisis,nutrient,servings
// $pdf->setX($x);
// $pdf->setY($y);

// SELECT `id`, `child_id`, `center_id`, `date_start`, `observation`, `status`, `user`, `date_end` FROM `rehabilitation` WHERE 1
//generated date
$gdt=date('Y-m-d');


$sql="SELECT * FROM  `rehabilitation` WHERE `date_start`='$gdt'";
// $sql="SELECT * FROM  `records` WHERE `status`='CENTER' AND `date`='$gdt'";
$vfn=mysqli_query($connect,$sql);
$num=1;
while ($fn=mysqli_fetch_array($vfn))
 {
	$em=$fn['child_id'];
	$hd=$fn['center_id'];
    $as=$fn['status'];
    $ds=$fn['date_start'];
    $de=$fn['date_end'];

    // $us=$fn['user'];


 
    //child name
    $kd="SELECT * FROM `children` WHERE `special_id`='$em'";
    $kdf=mysqli_query($connect,$kd);
    $kdd=mysqli_fetch_array($kdf);
    $emn=$kdd['full_name'];

    //center name
    $kdl="SELECT * FROM `locations` WHERE `special_id`='$hd'";
    $kdlz=mysqli_query($connect,$kdl);
    $kdlf=mysqli_fetch_array($kdlz);
    $center=$kdlf['center_name'];
    
    

// $x=30;
// $y=$y+40;
// $pdf->setX($x);
// $pdf->setY($y);
$pdf->SetFont('Arial','',12);
// $pdf->setX($x);
// $pdf->setY($y);
$pdf->cell(20,10,$num,1,0,'C');
$pdf->cell(60,10,$emn,1,0,'c');

// $x=$x+40;
// $pdf->setX($x);
// $pdf->setY($y);
$pdf->cell(60,10,$center,1,0,'c');
// $y=$y+30;
// $x=$x+40;
// $pdf->setX($x);
// $pdf->setY($y);

// $x=$x+40;
// $pdf->setX($x);
// $pdf->setY($y);
// $pdf->cell(30,10,$ag,1,0,'c');
// $x=$x+40;
// $pdf->setX($x);
// $pdf->setY($y);
$pdf->cell(40,10,$as,1,0,'c');

$pdf->cell(50,10,$ds,1,0,'c');
$pdf->cell(50,10,$de,1,1,'c');

// $pdf->cell(30,10,$as,1,1,'c');
$num++;
}
// query(query)
// connection


$pdf->output();

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Report Center PDF daily</title>
</head>
<body>
    
</body>
</html>