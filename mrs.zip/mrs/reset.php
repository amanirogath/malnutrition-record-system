<?php
$message="";
require("conn.php");
if(isset($_POST['send'])){
    $acc=mysqli_real_escape_string($connect,trim(htmlspecialchars($_POST['account'])));
   
    $vcal="SELECT `special_id`,`email` FROM `users` WHERE `email`='$acc'";
    $vly=mysqli_query($connect,$vcal);
    $vcou=mysqli_num_rows($vly);
    $identityf=mysqli_fetch_array($vly);
    $identity=$identityf['special_id'];


    if($vcou==1){

//email
require 'PHPMailerAutoload.php';   
$mail = new PHPMailer();
  $mail->IsSMTP();
  $mail->Mailer = "smtp";
  $mail->SMTPDebug = 0;
  $mail->SMTPAuth = TRUE;
  $mail->SMTPSecure = "ssl";
  $mail->Port = 465;
  $mail->Host = "comptectz.com";
  $mail->Username = "sms@comptectz.com";
  $mail->Password = "comptec@cmt";

$mail->setFrom('amarogath94@gmail.com', 'Malnutrition Records System');
$mail->addAddress($acc);     // Add a recipient
/*$mail->addAddress('ellen@example.com');*/               // Name is optional
$mail->addReplyTo('amarogath94@gmail.com', 'Information');
    // Optional name
$mail->isHTML(true);                                  // Set email format to HTML

$mail->Subject = 'M.R.S REGISTRATION';
$mail->Body    = '<div>Hello, <br><br> please recover your account by clicking the link bellow </br> <a href="http://localhost/mrs/recover.php?key='.$identity.'">Recover password</a>.
</div>';
$mail->AltBody = '';
//email end


if(!$mail->send()) {
    echo 'Email could not be sent.';
    echo 'Mailer Error: ' . $mail->ErrorInfo;
} else {
    // echo 'Email has been sent';



        $message="<div class='alert alert-info alert-dismissible fade show'>
        <svg viewBox='0 0 24 24' width='24' height='24' stroke='currentColor' stroke-width='2' fill='none' stroke-linecap='round' stroke-linejoin='round' class='mr-2'><circle cx='12' cy='12' r='10'></circle><line x1='12' y1='16' x2='12' y2='12'></line><line x1='12' y1='8' x2='12.01' y2='8'></line></svg>
        <strong>Email is sent to your account</strong>.
        <button type='button' class='close h-100' data-dismiss='alert' aria-label='Close'><span><i class='fas-fa times'></i></span>
        </button>
    </div>";

}
    }
else{
 $message="<div class='alert alert-warning alert-dismissible fade show'>
    <svg viewBox='0 0 24 24' width='24' height='24' stroke='currentColor' stroke-width='2' fill='none' stroke-linecap='round' stroke-linejoin='round' class='mr-2'><path d='M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z'></path><line x1='12' y1='9' x2='12' y2='13'></line><line x1='12' y1='17' x2='12.01' y2='17'></line></svg>
	 <strong>Account dosen't exist</strong>.
    <button type='button' class='close h-100' data-dismiss='alert' aria-label='Close'><span><i class='mdi mdi-close'></i></span>
    </button>
</div>";  
}

}
?>
<!DOCTYPE html>
<html lang="en" class="h-100">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title></title>
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="images/favicon.png">
    <link href="css/style.css" rel="stylesheet">

</head>

<body class="h-100">
    <div class="authincation h-100">
        <div class="container h-100">
            <div class="row justify-content-center h-100 align-items-center">
                <div class="col-md-6">
                    <div class="authincation-content">
                        <div class="row no-gutters">
                            <div class="col-xl-12">
                                <div class="auth-form">
                                    <h4 class="text-center mb-4">Forgot Password</h4>
                                    <form method="POST">
                                        <div class="form-group">
                                            <label><strong>Email</strong></label>
                                            <input type="email" name="account" required="required" class="form-control" placeholder="Enter your email">
                                        </div>
                                        <?php echo $message ;?>
                                        <div class="text-center">
                                            <button type="submit" name="send" class="btn btn-success btn-block">SUBMIT</button>
                                        </div>
                                    </form>
                                    <div class="new-account mt-3">
                                        <p><a class="text-primary" href="index.php">Go to sign in</a></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <!--**********************************
        Scripts
    ***********************************-->
    <!-- Required vendors -->
    <script src="vendor/global/global.min.js"></script>
	<script src="vendor/bootstrap-select/dist/js/bootstrap-select.min.js"></script>
    <script src="js/custom.min.js"></script>
    <script src="js/deznav-init.js"></script>

</body>


</html>