<?php
session_start();
include('conn.php');
$outnum="";
$sas="";
if(empty($_SESSION['identity'])){
    header("location:index.php");
    die();
}

if(isset($_POST['fnd'])){
	header("location:result.php");
}

if (isset($_POST['gogo'])){
                                                            
    $sas=$_POST['gogo'];
              
 
    $out="SELECT * FROM `children` WHERE `full_name` LIKE '%$sas%' OR `dob` LIKE '%$sas%' OR `father_name` LIKE '%$sas%' OR `mother_name` LIKE '%$sas%' OR `address` LIKE '%$sas%'";
    $outone = mysqli_query($connect,$out);
   $outnum=mysqli_num_rows($outone);

}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Dashboard</title>
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="images/favicon.png">
    <link href="vendor/jqvmap/css/jqvmap.min.css" rel="stylesheet">
	<link rel="stylesheet" href="vendor/chartist/css/chartist.min.css">
    <link href="vendor/bootstrap-select/dist/css/bootstrap-select.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
	<link href="../../cdn.lineicons.com/2.0/LineIcons.css" rel="stylesheet">

</head>
<body>

<?php include("topbar.php");?>
        
       
        <!--**********************************
            Sidebar start
        ***********************************-->
        <?php

        $g=$_SESSION['stat'];
        
        if($g=="ADMIN"){
            include("sidebar.php");
								}
								else{
                                    include("userside.php");
								}

                                ?>
      
        <!--**********************************
            Sidebar end
        ***********************************-->
		
		<!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">
            <!-- row -->
			<div class="container-fluid">
				<div class="form-head d-flex mb-3 align-items-start">
					<div class="mr-auto d-none d-lg-block">
						<h2 class="text-black font-w600 mb-0">Search Children (s)</h2>
					
					</div>
					
					
				</div>
            
                <div class="">
         <form method="POST">
         <div class="form-group col-md-6">
                                        
                                                <input type="search" class="form-control" name="gogo" placeholder="Write your input and hit ENTER">
                                            </div>
    
         </form>
     </div>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title">
                                <?php

if($outnum==""){
    echo "Results (--)";
}
if($outnum!=""){
    echo "Results(".$outnum.")";
}

?>
                             </h4>
                               <br>
                                <h5 class="card-title">
                                <?php echo $sas;?>
                                </h5>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-responsive-md">
                                        <thead>
                                            <tr>
                                                <th style="width:80px;"><strong>#</strong></th>
                                                <th><strong>CHILD</strong></th>
                                                <th><strong>DOB</strong></th>
                                                <th><strong>GENDER</strong></th>
                                                <th><strong>CONTACTS</strong></th>
                                                <th><strong>STATUS</strong></th>
                                               <th><strong> <a href="addchild.php">ADD CHILD</a></strong></th>
                                            </tr>
                                        </thead>
                                        <tbody>
 <?php

if($outnum>0){
    $s=1;
    while($fe=mysqli_fetch_array($outone))
    {
// while ($fe=mysqli_fetch_array($er)) {
 
    $kii=$fe['special_id'];
 echo '<tr>';
 echo '<td>'.$s.'</td>';
 echo '<td><strong>'.$fe['full_name'].'</strong></td>';
 echo '<td>'.$fe['dob'].'</td>';
 echo '<td>'.$fe['gender'].'</td>';
 echo '<td>'.$fe['contacts'].'</td>';
 echo '<td><span class="badge light badge-success">'.$fe['status'].'</span></td>';
 echo '<td>
       <div class="dropdown">
         <button type="button" class="btn btn-success light sharp" data-toggle="dropdown">
             <svg width="20px" height="20px" viewBox="0 0 24 24" version="1.1"><g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd"><rect x="0" y="0" width="24" height="24"/><circle fill="#000000" cx="5" cy="12" r="2"/><circle fill="#000000" cx="12" cy="12" r="2"/><circle fill="#000000" cx="19" cy="12" r="2"/></g></svg>
         </button>
         <div class="dropdown-menu">
             <a class="dropdown-item" href="metrics.php?key='.$kii.'">Add metrics</a>
             <a class="dropdown-item" href="nextcenter.php?key='.$kii.'">Add to center</a>
         </div>
     </div>
 </td>'; 
 echo'</tr>';
 $s++;
}
}
?>

                
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
				
				 </div>
            
        </div>
        <!--**********************************
            Content body end
        ***********************************-->

        <!--**********************************
            Footer start
        ***********************************-->
        <div class="footer">
            <div class="copyright">
                <p>Copyright © Developed by <a href="">Amani R Leoni </a> 2021-<?php echo date("Y");?></p>
            </div>
        </div>
        <!--**********************************
            Footer end
        ***********************************-->

		<!--**********************************
           Support ticket button start
        ***********************************-->

        <!--**********************************
           Support ticket button end
        ***********************************-->


    </div>
    <!--**********************************
        Main wrapper end
    ***********************************-->

    <!--**********************************
        Scripts
    ***********************************-->
    <!-- Required vendors -->
    <script src="vendor/global/global.min.js"></script>
	<script src="vendor/bootstrap-select/dist/js/bootstrap-select.min.js"></script>
	<script src="vendor/chart.js/Chart.bundle.min.js"></script>
    <script src="js/custom.min.js"></script>
	<script src="js/deznav-init.js"></script>
	
	<!-- Counter Up -->
    <script src="vendor/waypoints/jquery.waypoints.min.js"></script>
    <script src="vendor/jquery.counterup/jquery.counterup.min.js"></script>	
		
	<!-- Apex Chart -->
	<script src="vendor/apexchart/apexchart.js"></script>	
	
	<!-- Chart piety plugin files -->
	<script src="vendor/peity/jquery.peity.min.js"></script>
	
	<!-- Dashboard 1 -->
	<script src="js/dashboard/dashboard-1.js"></script>
	
	
</body>

</html>