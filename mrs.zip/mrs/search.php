<?php
$message="";

session_start();
if(empty($_SESSION['identity'])){
    header("location:index.php");
    die();
}

include('conn.php');
if(isset($_POST['fnd'])){
	header("location:result.php");
}

if(isset($_POST['go'])){
    $a=$_POST['search'];
   $_SESSION['search']=$a;

    header("location:reportsearch.php");
   }
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Dashboard</title>
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="images/favicon.png">
    <link href="vendor/jqvmap/css/jqvmap.min.css" rel="stylesheet">
	<link rel="stylesheet" href="vendor/chartist/css/chartist.min.css">
    <link href="vendor/bootstrap-select/dist/css/bootstrap-select.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
	<link href="../../cdn.lineicons.com/2.0/LineIcons.css" rel="stylesheet">

</head>
<body>

<?php include("topbar.php");?>
 

 <!--**********************************
     Sidebar start
 ***********************************-->

 <?php

$g=$_SESSION['stat'];

if($g=="ADMIN"){
include("sidebar.php");
                 }
                 else{
                   die();
                 }

                 ?>
     
        <!--**********************************
            Sidebar end
        ***********************************-->
		
		<!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">
            <!-- row -->
			<div class="container-fluid">
				<div class="form-head d-flex mb-3 align-items-start">
					<div class="mr-auto d-none d-lg-block">
						<h2 class="text-black font-w600 mb-0">Date Choice report</h2>
					
					</div>
					
					
				</div>
            
				

                <div class="col-xl-12 col-lg-12">
                        <div class="card">
                        <div class="card-header">
                        <p>Choose Time interval</p>
                            </div>
                            <?php echo $message; ?>

                            <div class="card-body">
                                <div class="basic-form">
                                    <form method="POST">

                                        <div class="form-row">
                                            <div class="form-group col-md-6">
                                                <label>search</label>
                                                <input type="search" name="search" class="form-control" placeholder="please write your keyword" required="required">
                                            </div>
 
                                        </div>
                                        <div class="form-group col-md-6">
                                        <label></label>
                                        <button type="submit" name="go" class="btn btn-success">create pdf</button>
                                   
                                              </div> 
                                    </form>
                                </div>
                            </div>
                        </div>
					</div>
 			
				
				 </div>
            
        </div>
        <!--**********************************
            Content body end
        ***********************************-->

        <!--**********************************
            Footer start
        ***********************************-->
        <div class="footer">
            <div class="copyright">
                <p>Copyright © Developed by <a href="">Amani R Leoni </a> 2021-<?php echo date("Y");?></p>
            </div>
        </div>
        <!--**********************************
            Footer end
        ***********************************-->

		<!--**********************************
           Support ticket button start
        ***********************************-->

        <!--**********************************
           Support ticket button end
        ***********************************-->


    </div>
    <!--**********************************
        Main wrapper end
    ***********************************-->

    <!--**********************************
        Scripts
    ***********************************-->
    <!-- Required vendors -->
    <script src="vendor/global/global.min.js"></script>
	<script src="vendor/bootstrap-select/dist/js/bootstrap-select.min.js"></script>
	<script src="vendor/chart.js/Chart.bundle.min.js"></script>
    <script src="js/custom.min.js"></script>
	<script src="js/deznav-init.js"></script>
	
	<!-- Counter Up -->
    <script src="vendor/waypoints/jquery.waypoints.min.js"></script>
    <script src="vendor/jquery.counterup/jquery.counterup.min.js"></script>	
		
	<!-- Apex Chart -->
	<script src="vendor/apexchart/apexchart.js"></script>	
	
	<!-- Chart piety plugin files -->
	<script src="vendor/peity/jquery.peity.min.js"></script>
	
	<!-- Dashboard 1 -->
	<script src="js/dashboard/dashboard-1.js"></script>
	
	
</body>

</html>