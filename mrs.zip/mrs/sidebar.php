<?php
      echo"
       <div class='deznav'>
           <div class='deznav-scroll'>
               <ul class='metismenu' id='menu'>
          
                   <li><a class='has-arrow ai-icon' href='javascript:void()' aria-expanded='false'>
                           <i class='flaticon-381-networking'></i>
                           <span class='nav-text'>Dashboard</span>
                       </a>
                       <ul aria-expanded='false'>
                       <li><a href='addchild.php'>Add child</a></li>
                           <li><a href='children.php'>View childrens</a></li>                      
                           <li><a href='addlocation.php'>Add center locaction</a></li>
                           <li><a href='viewlocation.php'>View center locaction</a></li>
                       </ul>
                   </li>
                  
                   <li><a class='has-arrow ai-icon' href='javascript:void()' aria-expanded='false'>
                           <i class='flaticon-381-notepad'></i>
                           <span class='nav-text'>Supplimentation</span>
                       </a>
                       <ul aria-expanded='false'>
                           <li><a href='addmedication.php'>Add Supplimentation</a></li>
                           <li><a href='viewmedication.php'>View Supplimentation</a></li>
                          
                       </ul>
                   </li>
                  
                 
                 
                  
                   <li><a class='has-arrow ai-icon' href='javascript:void()' aria-expanded='false'>
                           <i class='flaticon-381-layer-1'></i>
                           <span class='nav-text'>rehabilitation</span>
                       </a>
                       <ul aria-expanded='false'>
                       <li><a href='addtocenter.php'>add child to center</a></li>
                       <li><a href='viewcenter.php'>center records</a></a></li>
                          
                       </ul>
                   </li>
                   <li><a class='has-arrow ai-icon' href='javascript:void()' aria-expanded='false'>
                           <i class='flaticon-381-internet'></i>
                           <span class='nav-text'>Staffs</span>
                       </a>
                       <ul aria-expanded='false'>
                           <li><a href='addstaff.php'>Add Staff</a></li>
                           <li><a href='viewstaff.php'>View Staffs</a></li>
                          
                       </ul>
                   </li>
                   <li><a class='has-arrow ai-icon' href='javascript:void()' aria-expanded='false'>
                           <i class='flaticon-381-heart'></i>
                           <span class='nav-text'>Reports</span>
                       </a>
                       <ul aria-expanded='false'>
                       <li><a href='centerreport.php'>Date choice report</a></li>
                       <li><a href='dissorder.php'>dissorder report</a></li>
                       <li><a href='search.php'>Report by search</a></li>
                       </ul>
                   </li>

                   <li><a class='has-arrow ai-icon' href='javascript:void()' aria-expanded='false'>
                   <i class='flaticon-381-controls-3'></i>
                   <span class='nav-text'>Manage</span>
               </a>
               <ul aria-expanded='false'>
               <li><a href='profile.php'>Manage My Profile</a></a></li>
               <li><a href='changemypassword.php'>Change Password</a></a></li>
               <li><a href='logs.php'>View Users log</a></a></li>
               <li><a href='addnotification.php'>Add Notification</a></li>
               </ul>
           </li>
               </ul>
           
           
               
           </div>
       </div>
    ";
?>