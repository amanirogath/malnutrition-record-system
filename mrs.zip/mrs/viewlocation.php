<?php
session_start();
include('conn.php');
if(empty($_SESSION['identity'])){
    header("location:index.php");
    die();
}

if(isset($_POST['fnd'])){
	header("location:result.php");
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Dashboard</title>
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="images/favicon.png">
    <link href="vendor/jqvmap/css/jqvmap.min.css" rel="stylesheet">
	<link rel="stylesheet" href="vendor/chartist/css/chartist.min.css">
    <link href="vendor/bootstrap-select/dist/css/bootstrap-select.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
	<link href="../../cdn.lineicons.com/2.0/LineIcons.css" rel="stylesheet">

</head>
<body>

  
<?php include("topbar.php");?>
        
       
        <!--**********************************
            Sidebar start
        ***********************************-->
        <?php

        $g=$_SESSION['stat'];
        
        if($g=="ADMIN"){
            include("sidebar.php");
								}
								else{
                                    include("userside.php");
								}

                                ?>
        <!--**********************************
            Sidebar end
        ***********************************-->
		
		<!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">
            <!-- row -->
			<div class="container-fluid">
				<div class="form-head d-flex mb-3 align-items-start">
					<div class="mr-auto d-none d-lg-block">
						<h2 class="text-black font-w600 mb-0">View Center Location</h2>
					
					</div>
					
					
				</div>
            
				
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title">Table of Center Locations</h4>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-responsive-md">
                                        <thead>
                                            <tr>
                                            <!-- SELECT `id`, `special_id`, `country`, `region`, `district`, 
                                            `ward`, `village`, `center_name` FROM `locations` WHERE 1
                                             -->
                                                <th style="width:80px;"><strong>#</strong></th>
                                                <th><strong>CENTER NAME</strong></th>
                                                <th><strong>REGION</strong></th>
                                                <th><strong>DISTRICT</strong></th>
                                                <th><strong>WARD</strong></th>
                                                <th><strong>VILLAGE</strong></th>
                                                <th><strong>COUNTRY</strong></th>
                                               <th><strong> <a href="addlocation.php">+ ADD LOCATION</a></strong></th>
                                            </tr>
                                        </thead>
                                        <tbody>
 <?php
 $re="SELECT * FROM `locations`";
$er=mysqli_query($connect,$re);

$s=1;

while ($fe=mysqli_fetch_array($er)) {
 
    $kii=$fe['special_id'];
 echo '<tr>';
 echo '<td>'.$s.'</td>';
 echo '<td><strong>'.$fe['center_name'].'</strong></td>';
 echo '<td>'.$fe['region'].'</td>';
 echo '<td>'.$fe['district'].'</td>';
 echo '<td>'.$fe['ward'].'</td>';
 echo '<td>'.$fe['village'].'</td>';
 echo '<td>'.$fe['country'].'</td>';
//  echo '<td>UPDATE</td>';
 
 echo'</tr>';
 $s++;
}
?>

                
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
				
				 </div>
            
        </div>
        <!--**********************************
            Content body end
        ***********************************-->

        <!--**********************************
            Footer start
        ***********************************-->
        <div class="footer">
            <div class="copyright">
                <p>Copyright © Developed by <a href="">Amani R Leoni </a> 2021-<?php echo date("Y");?></p>
            </div>
        </div>
        <!--**********************************
            Footer end
        ***********************************-->

		<!--**********************************
           Support ticket button start
        ***********************************-->

        <!--**********************************
           Support ticket button end
        ***********************************-->


    </div>
    <!--**********************************
        Main wrapper end
    ***********************************-->

    <!--**********************************
        Scripts
    ***********************************-->
    <!-- Required vendors -->
    <script src="vendor/global/global.min.js"></script>
	<script src="vendor/bootstrap-select/dist/js/bootstrap-select.min.js"></script>
	<script src="vendor/chart.js/Chart.bundle.min.js"></script>
    <script src="js/custom.min.js"></script>
	<script src="js/deznav-init.js"></script>
	
	<!-- Counter Up -->
    <script src="vendor/waypoints/jquery.waypoints.min.js"></script>
    <script src="vendor/jquery.counterup/jquery.counterup.min.js"></script>	
		
	<!-- Apex Chart -->
	<script src="vendor/apexchart/apexchart.js"></script>	
	
	<!-- Chart piety plugin files -->
	<script src="vendor/peity/jquery.peity.min.js"></script>
	
	<!-- Dashboard 1 -->
	<script src="js/dashboard/dashboard-1.js"></script>
	
	
</body>

</html>