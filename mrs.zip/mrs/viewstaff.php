<?php
session_start();
include('conn.php');
if(empty($_SESSION['identity'])){
    header("location:index.php");
    die();
}

if(isset($_POST['fnd'])){
	header("location:result.php");
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Dashboard</title>
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="images/favicon.png">
    <link href="vendor/jqvmap/css/jqvmap.min.css" rel="stylesheet">
	<link rel="stylesheet" href="vendor/chartist/css/chartist.min.css">
    <link href="vendor/bootstrap-select/dist/css/bootstrap-select.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
	<link href="../../cdn.lineicons.com/2.0/LineIcons.css" rel="stylesheet">

</head>
<body>

<?php include("topbar.php");?>
 

 <!--**********************************
     Sidebar start
 ***********************************-->

 <?php

$g=$_SESSION['stat'];

if($g=="ADMIN"){
include("sidebar.php");
                 }
                 else{
                   die();
                 }

                 ?>
     
        <!--**********************************
            Sidebar end
        ***********************************-->
		
		<!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">
            <!-- row -->
			<div class="container-fluid">
				<div class="form-head d-flex mb-3 align-items-start">
					<div class="mr-auto d-none d-lg-block">
						<h2 class="text-black font-w600 mb-0">Staffs</h2>
					
					</div>
					
					
				</div>
            
				
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title">Table of Staffs</h4>
                            </div>

                            <!-- INSERT INTO `users`(`id`, `special_id`, `first`, `last`, `age`, `email`, `password`) e-7]) -->
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-responsive-md">
                                        <thead>
                                            <tr>
                                                <th style="width:80px;"><strong>#</strong></th>
                                                <th><strong>FIRST NAME</strong></th>
                                                <th><strong>LAST NAME</strong></th>
                                                <th><strong>AGE</strong></th>
                                                <th><strong>EMAIL</strong></th>
                                                <th><strong>STATUS</strong></th>
                                         
                                            </tr>
                                        </thead>
                                        <tbody>
 <?php
 $re="SELECT * FROM `users`";
$er=mysqli_query($connect,$re);

$s=1;
  // <!-- INSERT INTO `users`(`id`, `special_id`, `first`, `last`, `age`, `email`, `password`) e-7]) -->
while ($fe=mysqli_fetch_array($er)) {
$kdy=$fe['special_id'];
 echo '<tr>';
 echo '<td>'.$s.'</td>';

 echo '<td><strong>'.$fe['first'].'</strong></td>';
 echo '<td>'.$fe['last'].'</td>';
 echo '<td>'.$fe['age'].'</td>';
 echo '<td>'.$fe['email'].'</td>';
 echo '<td><span class="badge light badge-warning">'.$fe['status'].'</span></td>';

 echo '<td>
 <div class="dropdown">
   <button type="button" class="btn btn-success light sharp" data-toggle="dropdown">
       <svg width="20px" height="20px" viewBox="0 0 24 24" version="1.1"><g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd"><rect x="0" y="0" width="24" height="24"/><circle fill="#000000" cx="5" cy="12" r="2"/><circle fill="#000000" cx="12" cy="12" r="2"/><circle fill="#000000" cx="19" cy="12" r="2"/></g></svg>
   </button>
   <div class="dropdown-menu">
       <a class="dropdown-item" href="makeadmin.php?key='.$kdy.'">Make Admin</a>
       <a class="dropdown-item" href="updatestaff.php?key='.$kdy.'">Update</a>
       <a class="dropdown-item" href="deletestaff.php?key='.$kdy.'">Delete</a>
   </div>
</div>
</td>';
 echo'</tr>';
 $s++;
}
?>

                
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
				
				 </div>
            
        </div>
        <!--**********************************
            Content body end
        ***********************************-->

        <!--**********************************
            Footer start
        ***********************************-->
        <div class="footer">
            <div class="copyright">
                <p>Copyright © Developed by <a href="">Amani R Leoni </a> 2021-<?php echo date("Y");?></p>
            </div>
        </div>
        <!--**********************************
            Footer end
        ***********************************-->

		<!--**********************************
           Support ticket button start
        ***********************************-->

        <!--**********************************
           Support ticket button end
        ***********************************-->


    </div>
    <!--**********************************
        Main wrapper end
    ***********************************-->

    <!--**********************************
        Scripts
    ***********************************-->
    <!-- Required vendors -->
    <script src="vendor/global/global.min.js"></script>
	<script src="vendor/bootstrap-select/dist/js/bootstrap-select.min.js"></script>
	<script src="vendor/chart.js/Chart.bundle.min.js"></script>
    <script src="js/custom.min.js"></script>
	<script src="js/deznav-init.js"></script>
	
	<!-- Counter Up -->
    <script src="vendor/waypoints/jquery.waypoints.min.js"></script>
    <script src="vendor/jquery.counterup/jquery.counterup.min.js"></script>	
		
	<!-- Apex Chart -->
	<script src="vendor/apexchart/apexchart.js"></script>	
	
	<!-- Chart piety plugin files -->
	<script src="vendor/peity/jquery.peity.min.js"></script>
	
	<!-- Dashboard 1 -->
	<script src="js/dashboard/dashboard-1.js"></script>
	
	
</body>

</html>